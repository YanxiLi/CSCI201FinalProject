package classes;

public class NormUser extends User{
    /*
    public classes.NormUser(String username, int Id){
        super(username,Id);
    }*/
    public String type(){
        return "normuser";
    }
}