import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@javax.servlet.annotation.WebServlet("/Signout")
public class Signout extends HttpServlet {
    private static final long serialVersionUID = 1L;
    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        response.getWriter().append("Served at: ").append(request.getContextPath());
    }
    protected void service(javax.servlet.http.HttpServletRequest request,javax.servlet.http.HttpServletResponse response)throws javax.servlet.ServletException,IOException {
        String pageToForward = "/homepage.html";
        javax.servlet.http.HttpSession session = request.getSession();
        session.invalidate();

        response.sendRedirect("/homepage.html");
        //javax.servlet.RequestDispatcher dispatch = getServletContext().getRequestDispatcher(pageToForward);
        //dispatch.forward(request, response);
    }
}
