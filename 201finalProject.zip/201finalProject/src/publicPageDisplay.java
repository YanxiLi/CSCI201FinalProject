import jdbc.JdbcClass;

import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
@javax.servlet.annotation.WebServlet("/publicPageDisplay")
public class publicPageDisplay extends javax.servlet.http.HttpServlet {
    private static final long serialVersionUID = 1L;
    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        response.getWriter().append("Served at: ").append(request.getContextPath());
    }
    protected void service(javax.servlet.http.HttpServletRequest request,javax.servlet.http.HttpServletResponse response)throws javax.servlet.ServletException,IOException{
        javax.servlet.http.HttpSession session = request.getSession();
        JdbcClass jdbc = new JdbcClass();
        List<String> courseName = null;
        List<Integer> courseId = null;
        List<Integer> questionsId = null;
        int userIdint = (int) session.getAttribute("currentuser");
        String userIdString = Integer.toString(userIdint);
        session.setAttribute("currentuser",userIdString);
        String userId = (String) session.getAttribute("currentuser");
        try {
            courseName = jdbc.getCourseNameTakingForUser(Integer.parseInt(userId));
            courseId = jdbc.getCourseIdTakingForUser(Integer.parseInt(userId));
            questionsId = jdbc.getTenQuestions(0);
        }catch (java.sql.SQLException sqle){
            System.out.println("1"+sqle.getMessage());
        }

                   //List<String> courseName = new ArrayList<String>(Arrays.asList("CS201 Your Father","CS270 Your mother","CS104 Your Grandpa","CS170 Your son","CS103 GOD NO","CS102 Wait what"));
                   //List<String> profName = new ArrayList<String>(Arrays.asList("John M. Killer","Aaron C. Dumped","Aaron S. Fault","Shindler List","Badney","Wait who"));
                   //List<String> posts = new ArrayList<String>(Arrays.asList("post1","post2","post3","post4","post5","post6","post7","post8","post9","post10"));
                   //List<String> questioner = new ArrayList<String>(Arrays.asList("user1","user2","user3","user4","user5","user6","user7","user8","user9","user10"));

        List<String> questionsTitle = new ArrayList();

        for(int i=0;i<questionsId.size();i++){
            try {
                questionsTitle.add(jdbc.getQuestion(questionsId.get(i)).getTitle());
            }catch(java.sql.SQLException sqle){
                System.out.println("2"+sqle.getMessage());
            }
        }
        for(int i=0;i<questionsId.size();i++){
            System.out.println(questionsId.get(i));
            System.out.println(questionsTitle.get(i));
        }
        session.setAttribute("questionsId",questionsId);
        session.setAttribute("posts",questionsTitle);
        session.setAttribute("courseNameList",courseName);
        session.setAttribute("courseIdList",courseId);
        System.out.println("course Name: ");
        for(int i=0;i<courseName.size();i++){
            System.out.println(courseName.get(i));
        }
        System.out.println("course id: ");
        for(int i=0;i<courseId.size();i++){
            System.out.println(courseId.get(i));
        }

                    //session.setAttribute("posts",posts);

        String pageToForward = "/PublicPage.jsp";
        javax.servlet.RequestDispatcher dispatch = getServletContext().getRequestDispatcher(pageToForward);
        dispatch.forward(request, response);
    }
}
