import jdbc.JdbcClass;
import users.Question;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "EndorseAnswer", urlPatterns = {"/EndorseAnswer"})
public class EndorseAnswer extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void service(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        javax.servlet.http.HttpSession session = request.getSession();
        //User user = (Users) session.getParameter("currentuser");
        int userid = (int) session.getAttribute("currentuser");
        String questionId = (String) session.getAttribute("currentQuestionId");
        String Id = request.getParameter("id");
        String type = request.getParameter("type");
        JdbcClass jdbc = new JdbcClass();
        System.out.println(1);
        if(type.equals("question")){
            System.out.println("id"+Id+"user"+userid);

            try{
                jdbc.endorseQuestion(userid, Integer.parseInt(Id));
            }catch (java.sql.SQLException sqle) {
                System.out.println("-1" + sqle.getMessage());
            }
        }
        if(type.equals("answer")){
            try{
                jdbc.endorseAnswer(userid,Integer.parseInt(Id));
            }catch (java.sql.SQLException sqle) {
                System.out.println("-1" + sqle.getMessage());
            }
        }
        Question question = null;
        try {

            question = jdbc.getQuestion(Integer.parseInt(questionId));
        } catch (java.sql.SQLException sqle) {
            System.out.println("-1" + sqle.getMessage());
        }
        session.setAttribute("currentQuestion", question);
        //String pageToForward = "/PostPage.jsp";
        //javax.servlet.RequestDispatcher dispatch = getServletContext().getRequestDispatcher(pageToForward);
        //dispatch.forward(request, response);
    }
}
