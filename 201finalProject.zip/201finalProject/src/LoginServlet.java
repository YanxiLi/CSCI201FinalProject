import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpSession;
import java.io.PrintWriter;
import java.sql.SQLException;
import jdbc.JdbcClass;
@WebServlet(name = "LoginServlet",urlPatterns ={"/LoginServlet"})
public class LoginServlet extends HttpServlet {
    protected void service(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        PrintWriter  pw = response.getWriter();
        if(email == null || email.trim().length() == 0 || password == null || password.trim().length() == 0)
        {
            pw.println("Please fill in the blanks!");
        }
        else {
            JdbcClass database = new JdbcClass();

            boolean ifUser = false;
            boolean exist = false;
            try {
                exist = database.isEmailExist(email);
                ifUser = database.isUser(email, password);
            }catch (SQLException sqle) {
                System.out.println(sqle.getErrorCode());
            }if(!exist)
            {
                pw.println("Email does not exist!");

            }
            else if (!ifUser) {
                pw.println("Invalid password!");
            } else {
                HttpSession session = request.getSession();
                try {
                    session.setAttribute("currentuser", database.getUserId(email));//需要get ID function

                }catch(SQLException sqle){
                    System.out.println(sqle.getErrorCode());
                }
            }
        }
    }
}
