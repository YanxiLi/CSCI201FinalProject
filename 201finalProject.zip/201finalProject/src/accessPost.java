import javax.servlet.http.HttpServlet;
import java.io.IOException;

import jdbc.JdbcClass;
import users.Question;
@javax.servlet.annotation.WebServlet("/accessPost")
public class accessPost extends HttpServlet {
    private static final long serialVersionUID = 1L;
    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        response.getWriter().append("Served at: ").append(request.getContextPath());
    }
    protected void service(javax.servlet.http.HttpServletRequest request,javax.servlet.http.HttpServletResponse response)throws javax.servlet.ServletException,IOException {
        javax.servlet.http.HttpSession session = request.getSession();
        //User user = (Users) session.getParameter("currentuser");
        String questionId = request.getParameter("postId");
        session.setAttribute("currentQuestionId",questionId);
        JdbcClass jdbc = new JdbcClass();
        Question question = null;
        try{
            question = jdbc.getQuestion(Integer.parseInt(questionId));
        }catch(java.sql.SQLException sqle){
            System.out.println(sqle.getSQLState());
        }

        session.setAttribute("currentQuestion",question);
            //Question question = post.getPostQuestion();
            //String questionTile = question.getTitle();
            //String questionContent = question.getContent();
            //LocalDateTime timeAdded = question.getTimeAdded();
            //Int numberOfEndorsement = question.getEndorsement.size()
            //String userName = question.getUser().getUsername;
            //String category = question.getCategory();
        String pageToForward = "/PostPage.jsp";
        javax.servlet.RequestDispatcher dispatch = getServletContext().getRequestDispatcher(pageToForward);
        dispatch.forward(request, response);
    }
}
