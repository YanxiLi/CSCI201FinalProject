import jdbc.JdbcClass;
import users.Question;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDateTime;


@javax.servlet.annotation.WebServlet("/NewInput")
public class NewInput extends HttpServlet {
    private static final long serialVersionUID = 1L;
    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        response.getWriter().append("Served at: ").append(request.getContextPath());
    }
    protected void service(javax.servlet.http.HttpServletRequest request,javax.servlet.http.HttpServletResponse response)throws javax.servlet.ServletException,IOException {
        javax.servlet.http.HttpSession session = request.getSession();
        String inputType = request.getParameter("inputtype");
        String content = request.getParameter("newinput");
        String id = request.getParameter("id");
        Integer userid = (Integer) session.getAttribute("currentuser");
        String currentQuestionId = (String)session.getAttribute("currentQuestionId");
        JdbcClass jdbc = new JdbcClass();
        if (inputType.equals("comment")) {
            LocalDateTime now = LocalDateTime.now();
            try {
                jdbc.postCommentToAnswer(now, userid, content, Integer.parseInt(id));
            } catch (SQLException sqle) {
                System.out.println(sqle.getMessage());
            }
        }
        if (inputType.equals("answer")) {
            LocalDateTime now = LocalDateTime.now();
            try {
                jdbc.postAnswerToQuestion(now, content, userid, Integer.parseInt(id));
            } catch (SQLException sqle) {
                System.out.println(sqle.getMessage());
            }
        }
        Question question = null;
        try{
            question = jdbc.getQuestion(Integer.parseInt(currentQuestionId));
        }catch(java.sql.SQLException sqle){
            System.out.println("-1"+sqle.getMessage());
        }
        session.setAttribute("currentQuestion",question);
        //Question question = post.getPostQuestion();
        //String questionTile = question.getTitle();
        //String questionContent = question.getContent();
        //LocalDateTime timeAdded = question.getTimeAdded();
        //Int numberOfEndorsement = question.getEndorsement.size()
        //String userName = question.getUser().getUsername;
        //String category = question.getCategory();
        String pageToForward = "/PostPage.jsp";
        javax.servlet.RequestDispatcher dispatch = getServletContext().getRequestDispatcher(pageToForward);
        dispatch.forward(request, response);
    }
}
