package users;

public class NormUser {
    public String type(){
        return "normuser";
    }
}

