import jdbc.JdbcClass;
import users.Question;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/submitForm")
public class submitForm extends HttpServlet {
    private static final long serialVersionUID = 1L;
    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        response.getWriter().append("Served at: ").append(request.getContextPath());
    }
    protected void service(javax.servlet.http.HttpServletRequest request,javax.servlet.http.HttpServletResponse response)throws javax.servlet.ServletException,IOException {
        javax.servlet.http.HttpSession session = request.getSession();
        //User user = (Users) session.getParameter("currentuser");


        JdbcClass jdbc = new JdbcClass();
        int userId = (int)session.getAttribute("currentuser");
        String questionTitle = request.getParameter("title");
        String questionContent = request.getParameter("content");
        LocalDateTime now = LocalDateTime.now();
        try {
            jdbc.postQuestionForPublicPage(questionTitle, questionContent, now, userId,
                    1);
        }catch(SQLException sqle){
            System.out.println(sqle.getMessage());
        }
        List<Integer> questionsId = null;


        try {
            questionsId = jdbc.getAllQuestionsId();
        }catch (java.sql.SQLException sqle){
            System.out.println("1"+sqle.getMessage());
        }

        //List<String> courseName = new ArrayList<String>(Arrays.asList("CS201 Your Father","CS270 Your mother","CS104 Your Grandpa","CS170 Your son","CS103 GOD NO","CS102 Wait what"));
        //List<String> profName = new ArrayList<String>(Arrays.asList("John M. Killer","Aaron C. Dumped","Aaron S. Fault","Shindler List","Badney","Wait who"));
        //List<String> posts = new ArrayList<String>(Arrays.asList("post1","post2","post3","post4","post5","post6","post7","post8","post9","post10"));
        //List<String> questioner = new ArrayList<String>(Arrays.asList("user1","user2","user3","user4","user5","user6","user7","user8","user9","user10"));

        List<String> questionsTitle = new ArrayList();

        for(int i=0;i<questionsId.size();i++){
            try {
                questionsTitle.add(jdbc.getQuestion(questionsId.get(i)).getTitle());
            }catch(java.sql.SQLException sqle){
                System.out.println("2"+sqle.getMessage());
            }
        }
        session.setAttribute("questionsId",questionsId);
        session.setAttribute("posts",questionsTitle);



        String pageToForward = "/PublicPage.jsp";
        javax.servlet.RequestDispatcher dispatch = getServletContext().getRequestDispatcher(pageToForward);
        dispatch.forward(request, response);
    }
}
