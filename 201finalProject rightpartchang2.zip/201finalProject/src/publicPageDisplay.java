import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;
@javax.servlet.annotation.WebServlet("/publicPageDisplay")
public class publicPageDisplay extends javax.servlet.http.HttpServlet {
    private static final long serialVersionUID = 1L;
    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        response.getWriter().append("Served at: ").append(request.getContextPath());
    }
    protected void service(javax.servlet.http.HttpServletRequest request,javax.servlet.http.HttpServletResponse response)throws javax.servlet.ServletException,IOException{
        javax.servlet.http.HttpSession session = request.getSession();
        //User user = (Users) session.getParameter("user");
        List<String> courseName = new ArrayList<String>(Arrays.asList("CS201 Your Father","CS270 Your mother","CS104 Your Grandpa","CS170 Your son","CS103 GOD NO","CS102 Wait what"));
        List<String> profName = new ArrayList<String>(Arrays.asList("John M. Killer","Aaron C. Dumped","Aaron S. Fault","Shindler List","Badney","Wait who"));
        List<String> posts = new ArrayList<String>(Arrays.asList("post1","post2","post3","post4","post5","post6","post7","post8","post9","post10"));
        List<String> questioner = new ArrayList<String>(Arrays.asList("user1","user2","user3","user4","user5","user6","user7","user8","user9","user10"));
        session.setAttribute("courseName",courseName);
        session.setAttribute("profName",profName);
        session.setAttribute("posts",posts);
        session.setAttribute("questioner",questioner);
        String pageToFoward = "/PublicPage.jsp";
        javax.servlet.RequestDispatcher dispatch = getServletContext().getRequestDispatcher(pageToFoward);
        dispatch.forward(request, response);
    }
}
