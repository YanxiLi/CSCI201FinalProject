//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package servlet;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import Login.JdbcClass;

@WebServlet(
        name = "ChooseCoursePage",
        urlPatterns = {"/ChooseCoursePage"}
)
public class ChooseCoursePage extends HttpServlet {
    public ChooseCoursePage() {
    }

    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        JdbcClass jdbc = new JdbcClass();
        String in = request.getParameter("courseId");
        int courseid = Integer.parseInt(in);
        in = request.getParameter("userId");
        int userid = Integer.parseInt(in);
        HttpSession session = request.getSession();
        System.out.println(courseid);
        session.setAttribute("coursechoosen", courseid);
        session.setAttribute("clicktype", "announcement");
        session.setAttribute("index", 0);
        session.setAttribute("currentuser", userid);
        session.setAttribute("jdbc", jdbc);
        String pageToForward = "/coursepage.jsp";
        RequestDispatcher dispatch = this.getServletContext().getRequestDispatcher(pageToForward);
        dispatch.forward(request, response);
    }

}

