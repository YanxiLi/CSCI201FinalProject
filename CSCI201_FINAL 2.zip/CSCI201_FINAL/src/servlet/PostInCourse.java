//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDateTime;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import Login.JdbcClass;

@WebServlet(
        name = "PostInCourse",
        urlPatterns = {"/PostInCourse"}
)
public class PostInCourse extends HttpServlet {
    public PostInCourse() {
    }

    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String title = request.getParameter("title");
            String posttype = request.getParameter("posttype");
            String content = request.getParameter("content");
            HttpSession session = request.getSession();
            int currentuserid = (Integer)session.getAttribute("currentuser");
            int courseid = (Integer)session.getAttribute("coursechoosen");
            String pageToForward = "";
            JdbcClass jdbc = (JdbcClass)session.getAttribute("jdbc");
            LocalDateTime time = LocalDateTime.now();
            session.setAttribute("posterror", "");
            if (posttype.equals("announcement")) {
                if (jdbc.ifUserCanPostAnnouncement(currentuserid, courseid)) {
                    pageToForward = "/coursepage.jsp";
                    jdbc.postAnnouncementForCourse(title, content, time, currentuserid, courseid);
                } else {
                    pageToForward = "/postincoursepage.jsp";
                    session.setAttribute("posterror", "Sorry, you cannot post announcement.");
                }
            } else if (posttype.equalsIgnoreCase("question")) {
                pageToForward = "/coursepage.jsp";
                jdbc.postQuestionForCourse(title, content, time, currentuserid, 1, courseid);
            }

            RequestDispatcher dispatch = this.getServletContext().getRequestDispatcher(pageToForward);
            System.out.println(pageToForward);
            dispatch.forward(request, response);
        } catch (SQLException var13) {

        }

    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    }
}
