//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package classes;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Announcement {
    private int id;
    private String title;
    private List<Integer> followupId = new ArrayList();
    private int senderId;
    private LocalDateTime postDate;
    private String content;
    private int courseId;

    public Announcement(int id, String title, int senderId, String content, int courseId, LocalDateTime time) {
        this.id = id;
        this.courseId = courseId;
        this.senderId = senderId;
        this.title = title;
        this.content = content;
        this.postDate = time;
    }

    public int getId() {
        return this.id;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String newt) {
        this.title = newt;
    }

    public List<Integer> getFollowupId() {
        return this.followupId;
    }

    public void addFollowup(int id) {
        this.followupId.add(id);
    }

    public LocalDateTime getPostDate() {
        return this.postDate;
    }

    public String getContent() {
        return this.content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getSenderId() {
        return this.senderId;
    }

    public int getCourseId() {
        return this.courseId;
    }
}
