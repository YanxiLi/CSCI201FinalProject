//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//
package classes;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Question {
    private int id;
    private String title;
    private String content;
    private LocalDateTime postDate;
    private int senderId;
    private int category_id;
    private List<Integer> answersId = new ArrayList();

    public Question(int id, String title, int senderId, String content, LocalDateTime time, int category) {
        this.id = id;
        this.senderId = senderId;
        this.title = title;
        this.content = content;
        this.postDate = time;
        this.category_id = category;
    }

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return this.content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public LocalDateTime getTime() {
        return this.postDate;
    }

    public void setTime(LocalDateTime time) {
        this.postDate = time;
    }

    public int getUser_id() {
        return this.senderId;
    }

    public void setUser_id(int user_id) {
        this.senderId = user_id;
    }

    public int getCategory_id() {
        return this.category_id;
    }

    public void setCategory_id(int category_id) {
        this.category_id = category_id;
    }

    public List<Integer> getanswersId() {
        return this.answersId;
    }

    public void setAnswersId(List<Integer> answers) {
        this.answersId = answers;
    }
}
