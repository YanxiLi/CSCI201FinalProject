package Login;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

@WebServlet(name = "studentSignUpServlet",urlPatterns ={"/studentSignUpServlet"})
public class studentSignUpServlet extends HttpServlet {
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        {
            JdbcClass database = new JdbcClass();
            String email = request.getParameter("email");
            String password = request.getParameter("password");
            String lname = request.getParameter("lname");
            String fname = request.getParameter("fname");
            String username = request.getParameter("username");
            PrintWriter pw = response.getWriter();
            if (email == null || email.trim().length() == 0
                    ||password == null || password.trim().length() == 0
                    ||lname == null || lname.trim().length() == 0
                    ||fname == null || fname.trim().length() == 0
                    ||username == null || username.trim().length() == 0)
            {
                pw.println("Please fill in the blanks");
            }
            boolean exist = false;
            boolean passwordExist = true;
            try {
                exist = database.isEmailExist(email);
                passwordExist = database.getCorrespondingPassword(email);
            }catch(SQLException sqle)
            {
                System.out.println(sqle.getErrorCode());
            }

            if(!exist)
            {
                pw.println("Email does not exist, please use another one");
                pw.flush();
            }
            else if(passwordExist)
            {
                pw.println("The user has registered, please sign in.");
                pw.flush();
            }
            else
            {
                HttpSession session = request.getSession();
                try {
                    database.registerStudent(fname, lname, username, password, email);
                }catch (SQLException sqle)
                {
                    System.out.println(sqle.getErrorCode());
                }

                try {
                    session.setAttribute("currentuser", database.getUserId(email));
                }catch (SQLException sqle){
                    System.out.println(sqle.getErrorCode());
                }
            }
        }


    }

}
