package multithreading;
import sun.jvm.hotspot.runtime.Threads;

import java.net.*;
import java.util.*;
import java.io.*;

public class ServerThread extends Thread{
    private Socket s;
    private Server cs;
    private BufferedReader br;
    private PrintWriter pw;
    private Integer user;
    public ServerThread(Socket s, Server cs, Integer user)
    {
        this.s =s;
        this.cs=cs;
        this.user=user;
        try {
            this.br = new BufferedReader(new InputStreamReader(s.getInputStream()));
            this.pw = new PrintWriter(s.getOutputStream());
            this.start();
        }catch(IOException ioe)
        {
            System.out.println("ioe in ServerThread constructor: " + ioe.getMessage());
        }
    }
    public void sendMessage(String message)
    {
        pw.println(message);
        pw.flush();
    }
    public void run()
    {
        try {
            while(true)
            {
                String line = br.readLine();
                cs.broadcast(line, this.user,this, 1);
            }
        }
        catch(IOException ioe)
        {
            System.out.println("ioe in ServerThread.run()" + ioe.getMessage());
            cs.removeServerThread(this);
        }finally {
            try
            {
                br.close();
                pw.close();
                s.close();
            }catch(IOException ioe)
            { }
        }
    }

}
