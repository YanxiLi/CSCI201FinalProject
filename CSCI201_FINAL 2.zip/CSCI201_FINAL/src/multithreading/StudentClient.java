package multithreading;
import java.net.*;
import java.util.*;
import java.io.*;

public class StudentClient extends Thread {
    private BufferedReader br;
    private PrintWriter pw;
    public StudentClient(Integer userId, String hostname, int port)
    {
        try {
            System.out.println("Trying to connect to " + hostname + ":" + port);
            Socket s = new Socket(hostname, port);
            System.out.println("Connect to " + hostname + ":" + port);
            this.br = new BufferedReader(new InputStreamReader(s.getInputStream()));
            this.pw = new PrintWriter(s.getOutputStream());
            pw.println(userId);
            pw.flush();
            this.start();
        }catch(IOException ioe)
        {
            System.out.println("ioe in ProfessorClient constructor: " + ioe.getMessage());
        }
    }
    public void run()
    {
        try {
            while(true)
            {
                String line = br.readLine();
                System.out.println(line);
            }
        }catch(IOException ie)
        {
            System.out.println("ie in StudentClient run()" + ie.getMessage());
        }
    }
    public static void main(String args[])
    {
        new ProfessorClient(2,"localhost",6789);
    }
}
