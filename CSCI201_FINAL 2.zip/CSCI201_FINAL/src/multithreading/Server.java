package multithreading;

import Login.JdbcClass;

import java.io.*;
import java.net.*;
import java.sql.SQLException;
import java.util.*;
public class Server {
    private Map<Integer,ServerThread> serverThreads;
    private BufferedReader br;
    private PrintWriter pw;
    private ServerSocket ss;
    private Integer userId;
    public Server(int port){
        try {
            System.out.println("Trying to bind to port " + port);
            ServerSocket ss = new ServerSocket(port);
            System.out.println("Bound to port " + port);
            serverThreads = new HashMap<Integer,ServerThread>();
            while(true)
            {
                System.out.println("Waiting for connection...");
                Socket s = ss.accept();
                System.out.println("Connection from " + s.getInetAddress());
                Integer userId = Integer.parseInt(br.readLine());
                ServerThread st = new ServerThread(s, this,userId);
                serverThreads.put(userId,st);
            }
        }catch(IOException ioe)
        {
            System.out.println("ioe in Server constructor: "+ ioe.getMessage());
        }
    }
    public static void main(String[] args)
    {
        new Server(6789);
    }

    public void removeServerThread(ServerThread st)
    {
        serverThreads.remove(userId);
    }
    public void broadcast(String line, Integer currentUser,ServerThread currentThread,Integer CourseId)
    {
        System.out.println(line);
        JdbcClass database = new JdbcClass();
        List<Integer> courseUser = new ArrayList<>();
        try {
            courseUser = database.getUsersInCourse(CourseId);
        }catch(SQLException sqle)
        {
            sqle.fillInStackTrace();
        }
        for(Integer st : courseUser) {
            if (st != currentUser && serverThreads.containsKey(st)) {
                currentThread.sendMessage(line);
            }
        }
    }
}
